package net.codejava.SpringBootwebApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootwebAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootwebAppApplication.class, args);
	}

}
