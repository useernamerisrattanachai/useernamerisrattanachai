package net.codejava.SpringBootwebApp;

public class Contact {
	private String name ;
	private String email ;
	private String country ;
	public Contact() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Contact(String name, String email, String country) {
		super();
		this.name = name;
		this.email = email;
		this.country = country;
	}
	
}
